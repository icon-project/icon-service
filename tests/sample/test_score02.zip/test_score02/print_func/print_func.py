from ..test_func import test1_func


def func_test():
    test1_func()
