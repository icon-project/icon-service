# ICX Command Line Interface

ICX 코인과 관련된 기본적인 기능을 제공하는 Console 어플리케이션

## 실행 환경

* python3.6 이상 
* MacOS and Linux에서만 동작
* Windows에서는 실행되지 않음
  * secp256k1이 Windows에서 정상적으로 설치되지 않음

## 외부 라이브러리

icx_cli에서 사용하는 python 외부 라이브러리

* request
* [secp256k1](https://pypi.python.org/pypi/secp256k1): ECDSA 알고리즘 기반의 전자 서명 및 검증

## 기능

해당 CLI에서 제공하는 기능과 사용법을 설명한다.

* 도움말
* 계좌 생성
* 코인 이체
* 계좌 잔고 조회
* 전체 발급 코인 조회

### 도움말

도움말을 표시한다.

```shell
$ icx_cli.py --help
```

### 계좌 생성

ICX 코인을 관리할 수 있는 계좌를 생성한다.
실행할 때마다 새로운 계좌를 생성한다.
단, 이 어플에서는 해당 계좌를 파일로 저장하지 않는다. 저장은 100% 사용자의 몫이다.
이 어플에서는 실행할 때마다 개인키를 입력받아 사용할 뿐이다.

* Address: icx 코인 주소
* PrivateKey: 개인키 (32 bytes)
* PublicKey: 공개키 (64 bytes)

```shell
$ icx_cli.py createAccount
Address: hx407d73d8a49eeb85d32cf465507dd71d507100c1
PrivateKey: 0xa7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a
PublicKey: 0x......
```

### 코인 이체

ICX 코인을 다른 계좌 주소로 이체한다.

```shell
$ icx_cli.py icx_sendTransaction \
    --pk 0xa7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a \
    --from hx407d73d8a49eeb85d32cf465507dd71d507100c1 \
    --to hxcdf0686453a888b84f424d792af4b9202398f392 \
    --value 1.02 \
    --fee 0.01
```

### 계좌 잔고 조회

계좌의 잔고를 조회한다.
단위: 1/10^18 icx

```shell
$ icx_cli.py icx_getBalance --address hx407d73d8a49eeb85d32cf465507dd71d507100c1
icx: 1000.0
wei: 0x3635c9adc5dea00000
```

### 전체 발급 코인 조회

현재까지 발급된 총 코인의 수를 조회한다.
단위: 1/10^18 icx

```shell
$ icx_cli.py icx_getTotalSupply
icx: 800460000.0
wei: 0x2961fff8ca4a62327800000
```
