from setuptools import setup

def readme():
    with open('README.rst') as f:
        return f.read()

setup(name='icxcli',
    version='1.0',
    description='ICX Command Line Interface',
    long_description=readme(),
    classifiers=[
        'Development Status :: 3 - Alpha' ,
        'Programming Language :: Python :: 3.6',
        'Environment :: Console',
        'Topic :: Utilities'
    ],
    url='https://repo.theloop.co.kr/score/icx',
    author='goldworm',
    author_email='goldworm@icon.foundation',
    license='TheLoop CopyRight',
    packages=['icxcli'],
    install_requires=[ 'requests', 'secp256k1' ],
    zip_safe=False)
