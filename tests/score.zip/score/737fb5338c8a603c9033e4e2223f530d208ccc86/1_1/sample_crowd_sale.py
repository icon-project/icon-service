from iconservice.base.exception import IconScoreBaseException
from iconservice.base.address import Address
from iconservice.iconscore.icon_score_base import IconScoreBase, external, payable, score
from iconservice.database.db import IconScoreDatabase
from iconservice.iconscore.icon_container_db import DictDB, ArrayDB, VarDB


@score
class CrowdSale(IconScoreBase):
    _ADDR_BENEFICIARY = 'addr_beneficiary'
    _FUNDING_GOAL = 'funding_goal'
    _AMOUNT_RAISE = 'amount_raise'
    _DEAD_LINE = 'dead_line'
    _PRICE = 'price'
    _BALANCE_OF = 'balance_of'
    _FUNDING_GOAL_REACHED = 'funding_goal_reached'
    _CROWD_SALE_CLOSED = 'crowd_sale_closed'
    _JOINER_LIST = 'joiner_list'

    # token score address
    # 이미 토큰은 올라갔다고 가정.
    _ADDR_TOKEN_REWARD = '0x000000001'

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._addr_beneficiary = VarDB(self._ADDR_BENEFICIARY, db, value_type=Address)
        self._funding_goal = VarDB(self._FUNDING_GOAL, db, value_type=int)
        self._amout_raise = VarDB(self._AMOUNT_RAISE, db, value_type=int)
        self._dead_line = VarDB(self._DEAD_LINE, db, value_type=int)
        self._price = VarDB(self._PRICE, db, value_type=int)
        self._balance_of = DictDB(self._BALANCE_OF, db, value_type=int)
        self._joiner_list = ArrayDB(self._JOINER_LIST, db, value_type=Address)
        self._funding_goal_reached = VarDB(self._FUNDING_GOAL_REACHED, db, value_type=bool)
        self._crowd_sale_closed = VarDB(self._CROWD_SALE_CLOSED, db, value_type=bool)

    def genesis_init(self, if_successful_send_to: Address, funding_goal_in_icx: int,
                     duration_in_minutes: int, icx_cost_of_each_token: int,
                     address_of_token_used_as_reward: Address, *args, **kwargs) -> None:
        super().genesis_init(*args, **kwargs)

        one_icx = 1 * 10 * 18
        one_minutes = 1 * 60
        now_seconds = self.now_second()

        self._addr_beneficiary.set(if_successful_send_to)
        self._funding_goal = funding_goal_in_icx * one_icx
        self._dead_line = now_seconds + duration_in_minutes * one_minutes
        self._price = icx_cost_of_each_token * one_icx

    def __balance_of(self, addr_from: Address) -> int:
        var = self._balances[addr_from]
        if var is None:
            var = 0
        return var

    @external(readonly=True)
    def total_joiner_count(self):
        return len(self._joiner_list)

    @payable
    def fallback(self) -> None:
        if self._crowd_sale_closed.get():
            raise IconScoreBaseException('crowd sale is closed')

        amount = self.msg.value
        self._balance_of[self.msg.sender] = self.__balance_of(self.msg.sender) + amount
        self._amout_raise.set(self._amout_raise.get() + amount)
        addr_token = Address.from_string(self._ADDR_TOKEN_REWARD)
        self.call(addr_token, 'transfer', {'addr_to': self.msg.sender, 'value': amount/self._price.get()})

        if self.msg.sender not in self._joiner_list:
            self._joiner_list.put(self.msg.sender)

        # event FundTransfer(msg.sender, amont, True)

    @external
    def check_goal_reached(self):
        if not self.__after_dead_line():
            raise IconScoreBaseException('before deadline')

        if self._amout_raise.get() >= self._funding_goal.get():
            self._funding_goal_reached.set(True)
            # event GoalReached(beneficiary, amountRaised)
        self._crowd_sale_closed.set(True)

    def __after_dead_line(self):
        return self.now_second() >= self._dead_line.get()

    @external
    def safe_withdrawal(self):
        if not self.__after_dead_line():
            raise IconScoreBaseException('before deadline')

        if not self._funding_goal_reached.get():
            amount = self._balance_of[self.msg.sender]
            if amount > 0:
                if self.send(self.msg.sender, amount):
                    # event FundTransfer(msg.sender, amount, False)
                    pass
                else:
                    self._balance_of[self.msg.sender] = amount

        if self._funding_goal_reached.get() and self._addr_beneficiary.get() == self.msg.sender:
            if self.send(self._addr_beneficiary.get(), self._amout_raise.get()):
                # event FundTransfer(beneficiary, amountRaised, False)
                pass
            else:
                self._funding_goal_reached.set(False)
